import json
from ai_diagnosis import diagnose_crop_image
from urllib.request import urlopen
from urllib.parse import urlencode
from fastapi import APIRouter, Form, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse
import html

router = APIRouter()
CITIES = {
    "ঢাকা": (23.8103, 90.4125), "ফরিদপুর": (23.6070, 89.8429), "গাজীপুর": (24.0023, 90.4264),
    "গোপালগঞ্জ": (23.0051, 89.8266), "কিশোরগঞ্জ": (24.4260, 90.9821), "মাদারীপুর": (23.1641, 90.1897),
    "মানিকগঞ্জ": (23.8617, 90.0003), "মুন্সিগঞ্জ": (23.5422, 90.5305), "নারায়ণগঞ্জ": (23.6238, 90.5000),
    "নরসিংদী": (23.9229, 90.7177), "রাজবাড়ী": (23.7574, 89.6445), "শরীয়তপুর": (23.1279, 90.3000),
    "টাঙ্গাইল": (24.2513, 89.9167), "ময়মনসিংহ": (24.7471, 90.4203), "জামালপুর": (24.9375, 89.9378),
    "নেত্রকোনা": (24.8700, 90.7278), "শেরপুর": (25.0204, 90.0152), "বগুড়া": (24.8465, 89.3773),
    "জয়পুরহাট": (25.0968, 89.0227), "নওগাঁ": (24.7936, 88.9318), "নাটোর": (24.4206, 89.0000),
    "চাঁপাইনবাবগঞ্জ": (24.5965, 88.2775), "পাবনা": (24.0064, 89.2372), "রাজশাহী": (24.3745, 88.6042),
    "সিরাজগঞ্জ": (24.4534, 89.7007), "দিনাজপুর": (25.6279, 88.6332), "গাইবান্ধা": (25.3288, 89.5281),
    "কুড়িগ্রাম": (25.8054, 89.6362), "লালমনিরহাট": (25.9165, 89.4500), "নীলফামারী": (25.9318, 88.8560),
    "পঞ্চগড়": (26.3411, 88.5542), "রংপুর": (25.7439, 89.2752), "ঠাকুরগাঁও": (26.0336, 88.4617),
    "বরগুনা": (22.1592, 90.1266), "বরিশাল": (22.7010, 90.3535), "ভোলা": (22.6859, 90.6482),
    "ঝালকাঠি": (22.6406, 90.1987), "পটুয়াখালী": (22.3596, 90.3299), "পিরোজপুর": (22.5841, 89.9720),
    "বান্দরবান": (22.1953, 92.2184), "ব্রাহ্মণবাড়িয়া": (23.9571, 91.1119), "চাঁদপুর": (23.2333, 90.6712),
    "চট্টগ্রাম": (22.3569, 91.7832), "কুমিল্লা": (23.4607, 91.1809), "কক্সবাজার": (21.4272, 92.0058),
    "ফেনী": (23.0159, 91.3976), "খাগড়াছড়ি": (23.1193, 91.9847), "লক্ষ্মীপুর": (22.9447, 90.8282),
    "নোয়াখালী": (22.8696, 91.0995), "রাঙামাটি": (22.6533, 92.1750), "ঢাকা": (23.8103, 90.4125),
    "বাগেরহাট": (22.6516, 89.7859), "চুয়াডাঙ্গা": (23.6402, 88.8418), "যশোর": (23.1667, 89.2167),
    "ঝিনাইদহ": (23.5448, 89.1539), "খুলনা": (22.8456, 89.5403), "কুষ্টিয়া": (23.9013, 89.1205),
    "মাগুরা": (23.4873, 89.4190), "মেহেরপুর": (23.7622, 88.6318), "নড়াইল": (23.1725, 89.5127),
    "সাতক্ষীরা": (22.7185, 89.0705), "সিলেট": (24.8949, 91.8687), "হবিগঞ্জ": (24.3749, 91.4155),
    "মৌলভীবাজার": (24.4829, 91.7774), "সুনামগঞ্জ": (25.0658, 91.3950)
}
CROPS = ["ধান","গম","ভুট্টা","যব","জোয়ার","বাজরা","সরিষা","সূর্যমুখী","তিল","চিনাবাদাম","সয়াবিন","মসুর","মুগ","মাসকলাই","খেসারি","ছোলা","মটর","অড়হর","পাট","তুলা","আখ","তামাক","আলু","মিষ্টিআলু","মুখিকচু","কচু","ওল","টমেটো","বেগুন","মরিচ","ঢেঁড়স","লাউ","মিষ্টিকুমড়া","চালকুমড়া","করলা","উচ্ছে","চিচিঙ্গা","ধুন্দল","ঝিঙা","পটল","কাঁকরোল","শসা","খিরা","তরমুজ","বাঙ্গি","ফুটি","বাঁধাকপি","ফুলকপি","ব্রকলি","ওলকপি","গাজর","মূলা","শালগম","বিট","পেঁয়াজ","রসুন","আদা","হলুদ","ধনিয়া","জিরা","মেথি","কালোজিরা","লালশাক","ডাঁটাশাক","পুঁইশাক","পালংশাক","কলমিশাক","মালঞ্চশাক","পাটশাক","সরিষাশাক","মুলাশাক","লেটুস","ধনেপাতা","পুদিনা","কচুশাক","মাশরুম","আম","কাঁঠাল","লিচু","কলা","পেঁপে","পেয়ারা","জাম","জামরুল","কুল","বরই","আমড়া","জলপাই","বেল","কদবেল","তাল","নারিকেল","সুপারি","খেজুর","আনারস","লেবু","কাগজি লেবু","কমলা","মাল্টা","জাম্বুরা","মৌসুমি","সাতকরা","ডালিম","আতা","শরিফা","রামফল","কামরাঙা","লটকন","অলুবোখারা","ড্রাগন ফল","অ্যাভোকাডো","স্ট্রবেরি","আঙুর","আপেল","নাশপাতি","পিচ","প্লাম","প্যাশন ফল","রাম্বুটান","ম্যাঙ্গোস্টিন","সফেদা","আতাফল","গাব","ফলসা","করমচা","চালতা","বাতাবি লেবু","সজিনা","কাঁচকলা","মোচা","থোড়"]
LIVESTOCK_TYPES = ["মৎস্য চাষ","প্রাণিজ - গরু","প্রাণিজ - ছাগল","প্রাণিজ - ভেড়া","পোল্ট্রি - মুরগি","পোল্ট্রি - হাঁস","পোল্ট্রি - টার্কি","পোল্ট্রি - কোয়েল"]
DIAGNOSIS_TYPES = CROPS + LIVESTOCK_TYPES + ["অন্যান্য"]
UNITS = {"একর":1.0,"শতক":0.01,"বিঘা":0.33,"হেক্টর":2.471}

def shell(title, body):
    return f"""<!doctype html><html lang="bn"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#176b45"><title>{title} · iFarmer</title><link rel="stylesheet" href="/static/style.css"><body><header class="top"><a class="brand" href="/">🌱 iFarmer</a><nav><a href="/">হোম</a><a href="/agri">কৃষি সহায়ক</a></nav></header><main class="narrow section">{body}</main><footer><b>iFarmer</b><p>কৃষির ডিজিটাল সহযাত্রী</p></footer></body></html>"""

@router.get("/agri", response_class=HTMLResponse)
def agri_home():
    body = """<div class="eyebrow">কৃষকের ডিজিটাল সহকারী</div><h1>কৃষি সহায়ক</h1><p>আবহাওয়া, সার ও কীটনাশকের হিসাব এবং ফসলের ছবি জমা দেওয়ার সুবিধা।</p><div class="cards">
    <article class="card"><h2>📚 সরকারি সার সুপারিশ</h2><p>BARC, Crop Zoning ও DAE-এর সরকারি কৃষি তথ্যসূত্র দেখুন।</p><a class="btn primary" href="/agri/official-data">সরকারি তথ্য দেখুন</a></article><article class="card"><h2>🌦️ দৈনিক আবহাওয়া</h2><p>জেলা নির্বাচন করে তাপমাত্রা, বৃষ্টি, আর্দ্রতা ও বাতাসের তথ্য দেখুন।</p><a class="btn primary" href="/agri/weather">আবহাওয়া দেখুন</a></article>
    <article class="card"><h2>🧮 সার হিসাব</h2><p>কৃষি কর্মকর্তার সুপারিশকৃত একক মাত্রা দিয়ে জমির মোট পরিমাণ হিসাব করুন।</p><a class="btn primary" href="/agri/fertilizer">হিসাব করুন</a></article>
    <article class="card"><h2>🧴 কীটনাশক হিসাব</h2><p>শুধু পণ্যের অনুমোদিত লেবেলে লেখা মাত্রা বসিয়ে পরিমাণ হিসাব করুন।</p><a class="btn primary" href="/agri/pesticide">লেবেলভিত্তিক হিসাব</a></article>
    <article class="card"><h2>📖 তথ্যভাণ্ডার</h2><p>ফসল, মৎস্য, প্রাণিসম্পদ ও পোল্ট্রির তথ্য আলাদা বিভাগে দেখুন।</p><div class="actions"><a class="btn primary" href="/agri/category/fish">🐟 মৎস্য</a><a class="btn primary" href="/agri/category/livestock">🐄 প্রাণিসম্পদ</a><a class="btn primary" href="/agri/category/poultry">🐔 পোল্ট্রি</a><a class="btn light" href="/agri/guide">সকল তথ্য</a></div></article><article class="card"><h2>📷 রোগ-পোকা শনাক্তকরণ</h2><p>ফসলের আক্রান্ত অংশের ছবি আপলোড করুন। AI সম্ভাব্য রোগ, পোকা ও করণীয় বিশ্লেষণ করবে।</p><a class="btn primary" href="/agri/diagnose">ছবি জমা দিন</a></article></div>"""
    return shell("কৃষি সহায়ক", body)

CATEGORY_DATA = {
    "crop": {"title":"ফসল বিভাগ","icon":"🌾","items":CROPS,"desc":"ফসলের রোগ-পোকা, পুষ্টি, পরিচর্যা ও উৎপাদন বিষয়ে সহায়তা।"},
    "fish": {"title":"মৎস্য বিভাগ","icon":"🐟","items":["মৎস্য চাষ"],"desc":"মাছের চাষ, পানির গুণাগুণ, রোগ ও পরিচর্যার বিষয়ে সহায়তা।"},
    "livestock": {"title":"প্রাণিজ বিভাগ","icon":"🐄","items":["প্রাণিজ - গরু","প্রাণিজ - ছাগল","প্রাণিজ - ভেড়া"],"desc":"গরু, ছাগল ও ভেড়া পালন, খাদ্য ও স্বাস্থ্য বিষয়ে সহায়তা।"},
    "poultry": {"title":"পোল্ট্রি বিভাগ","icon":"🐔","items":["পোল্ট্রি - মুরগি","পোল্ট্রি - হাঁস","পোল্ট্রি - টার্কি","পোল্ট্রি - কোয়েল"],"desc":"মুরগি, হাঁস, টার্কি ও কোয়েল পালন ও স্বাস্থ্য ব্যবস্থাপনা।"},
}

@router.get("/agri/category/{category}", response_class=HTMLResponse)
def category_page(category: str, q: str = ""):
    data = CATEGORY_DATA.get(category)
    if not data:
        raise HTTPException(404, "বিভাগ পাওয়া যায়নি")
    query = q.strip().lower()
    matches = [item for item in data["items"] if query in item.lower()]
    options = "".join("<option>" + html.escape(item) + "</option>" for item in matches)
    cards = "".join(
        "<article class='card'><h3>" + html.escape(item) + "</h3><p>" + html.escape(data["desc"]) +
        "</p><a class='btn primary' href='/agri/diagnose?crop=" + urlencode({"crop": item})[5:] +
        "'>এই বিষয়ে ছবি দিয়ে বিশ্লেষণ</a></article>" for item in matches
    ) or "<article class='card'><p>আপনার খোঁজের সঙ্গে মেলে এমন কোনো বিষয় পাওয়া যায়নি।</p></article>"
    body = f"""<div class="eyebrow">iFarmer · কৃষি সহায়ক</div><h1>{data["icon"]} {data["title"]}</h1><p>{html.escape(data["desc"])}</p>
<form class="form card" method="get"><label>নাম দিয়ে খুঁজুন<input name="q" value="{html.escape(q, quote=True)}" placeholder="যেমন: ধান, গরু, মুরগি"></label><button class="btn primary">ফিল্টার করুন</button> <a class="btn light" href="/agri/category/{category}">সব দেখুন</a></form><div class="cards">{cards}</div><p><a href="/agri">কৃষি সহায়ক-এ ফিরে যান</a></p>"""
    return shell(data["title"], body)

@router.get("/agri/official-data", response_class=HTMLResponse)
def official_data():
    # Verified starter records transcribed from DAE BAMIS public crop package.
    # These are national/seasonal package values, not soil-test/union-specific advice.
    maize = {
        "Rabi": {"Urea": "172–312", "TSP": "168–216", "MOP": "96–144", "Gypsum": "144–168", "Zinc sulphate": "10–15", "Boric acid": "5–7 (প্রয়োজন অনুযায়ী)", "Gobar": "4–6"},
        "Kharif-1": {"Urea": "216–268", "TSP": "132–216", "MOP": "72–120", "Gypsum": "96–144", "Zinc sulphate": "7–12", "Boric acid": "5–7 (প্রয়োজন অনুযায়ী)", "Gobar": "4–6"}
    }
    rows = "".join(
        f"<tr><td>{html.escape(season)}</td><td>{html.escape(fertilizer)}</td><td>{html.escape(rate)}</td><td>কেজি/হেক্টর</td></tr>"
        for season, values in maize.items() for fertilizer, rate in values.items()
    )
    body = f"""<div class="eyebrow">সরকারি কৃষি তথ্য</div><h1>ফসলভিত্তিক সরকারি সার সুপারিশ</h1>
<p>প্রথম পর্যায়: নরসিংদী জেলার রায়পুরা উপজেলা। নিচে সরকারি BAMIS ফসল উৎপাদন প্যাকেজ থেকে যাচাই করে একটি প্রাথমিক রেকর্ড যুক্ত করা হয়েছে।</p>
<div class="card"><h2>🌽 ভুট্টা — সার সুপারিশ</h2><p><b>উৎস:</b> DAE BAMIS, ভুট্টা উৎপাদন প্যাকেজ।</p>
<table><thead><tr><th>মৌসুম</th><th>সার</th><th>মাত্রা</th><th>একক</th></tr></thead><tbody>{rows}</tbody></table>
<p class="fine">BAMIS প্যাকেজে দেওয়া জাতীয় মৌসুমভিত্তিক পরিসর। এটি রায়পুরার নির্দিষ্ট জমির মাটি-পরীক্ষাভিত্তিক সুপারিশ নয়। মাটির ধরন, জাত ও স্থানীয় কৃষি কর্মকর্তার পরামর্শ অনুযায়ী চূড়ান্ত মাত্রা নির্ধারণ করুন।</p>
<a href="https://www.bamis.gov.bd/en/croppnp/1/all/8/" target="_blank" rel="noopener">BAMIS-এর মূল ভুট্টা উৎপাদন প্যাকেজ</a></div>
<div class="card"><h2>🌾 বোরো ধান — সরকারি সার সুপারিশ</h2>
<p><b>উৎস:</b> DAE BAMIS, বোরো ধান উৎপাদন প্যাকেজ।</p>
<table><thead><tr><th>জমির ধরন</th><th>ইউরিয়া</th><th>TSP</th><th>MP</th><th>জিপসাম</th><th>জিংক সালফেট</th><th>একক</th></tr></thead><tbody>
<tr><td>নিচু জমি, দীর্ঘমেয়াদি</td><td>40</td><td>13</td><td>22</td><td>15</td><td>1.5</td><td>কেজি/বিঘা</td></tr>
<tr><td>মাঝারি জমি, স্বল্পমেয়াদি</td><td>35</td><td>12</td><td>20</td><td>15</td><td>1.5</td><td>কেজি/বিঘা</td></tr>
<tr><td>হাওর অঞ্চল</td><td>27</td><td>12</td><td>22</td><td>8</td><td>1.5</td><td>কেজি/বিঘা</td></tr></tbody></table>
<p class="fine">ইউরিয়া ৩ কিস্তিতে প্রয়োগের নির্দেশনাও BAMIS প্যাকেজে দেওয়া আছে। জমির ধরন, জাত ও স্থানীয় পরামর্শ অনুযায়ী প্রয়োগ করুন।</p>
<a href="https://www.bamis.gov.bd/en/croppnp/1/all/75/" target="_blank" rel="noopener">মূল বোরো ধান প্যাকেজ</a></div>
<div class="card"><h2>🌿 গম — সরকারি সার সুপারিশ</h2><p><b>উৎস:</b> DAE BAMIS, গম উৎপাদন প্যাকেজ।</p>
<table><thead><tr><th>সার</th><th>মাত্রা</th><th>একক</th></tr></thead><tbody>
<tr><td>ইউরিয়া (জমি তৈরির সময়)</td><td>150–175</td><td>কেজি/হেক্টর</td></tr>
<tr><td>TSP</td><td>135–150</td><td>কেজি/হেক্টর</td></tr>
<tr><td>পটাশ</td><td>100–110</td><td>কেজি/হেক্টর</td></tr>
<tr><td>জিপসাম</td><td>110–125</td><td>কেজি/হেক্টর</td></tr>
<tr><td>জিংক সালফেট</td><td>12.5</td><td>কেজি/হেক্টর</td></tr>
<tr><td>বোরিক অ্যাসিড</td><td>6.5</td><td>কেজি/হেক্টর</td></tr>
<tr><td>ইউরিয়া (৩ পাতার পর্যায়ে, সেচের সঙ্গে)</td><td>75–90</td><td>কেজি/হেক্টর</td></tr></tbody></table>
<a href="https://www.bamis.gov.bd/en/croppnp/1/all/9/" target="_blank" rel="noopener">মূল গম প্যাকেজ</a></div>
<div class="card"><h2>🥔 আলু — সরকারি সার সুপারিশ</h2><p><b>উৎস:</b> DAE BAMIS কৃষি আবহাওয়া বুলেটিনে প্রকাশিত আলু নির্দেশনা; জাতভেদে মাত্রা পরিবর্তন হতে পারে।</p>
<table><thead><tr><th>সার</th><th>মাত্রা</th><th>একক</th></tr></thead><tbody>
<tr><td>ইউরিয়া</td><td>160–175</td><td>কেজি/হেক্টর</td></tr>
<tr><td>TSP</td><td>200–220</td><td>কেজি/হেক্টর</td></tr>
<tr><td>MOP</td><td>250–300</td><td>কেজি/হেক্টর</td></tr>
<tr><td>জিপসাম</td><td>100–120</td><td>কেজি/হেক্টর</td></tr>
<tr><td>জিংক সালফেট</td><td>8–10</td><td>কেজি/হেক্টর</td></tr>
<tr><td>বোরিক অ্যাসিড</td><td>6–9</td><td>কেজি/হেক্টর</td></tr></tbody></table>
<p class="fine">প্রাথমিক/বেসাল প্রয়োগের নির্দেশনা। ইউরিয়ার টপ ড্রেসিংয়ের জন্য BAMIS বুলেটিনে রোপণের ৩০–৩৫ দিন পর ১৬০–১৭৫ কেজি/হেক্টর উল্লেখ আছে; জাত ও নির্দেশনা মিলিয়ে নিন।</p>
<a href="https://www.bamis.gov.bd/en/bulletin/view/38262/" target="_blank" rel="noopener">BAMIS আলু নির্দেশনা</a></div>
<h2>সরকারি তথ্যসূত্র</h2><ul>
<li><a href="https://portal.cropzoning.gov.bd/" target="_blank" rel="noopener">BARC কৃষি পরামর্শক বাতায়ন / Crop Zoning</a></li>
<li><a href="https://portal.cropzoning.gov.bd/cropSuitability" target="_blank" rel="noopener">উপজেলাভিত্তিক ফসলের উপযোগিতা</a></li>
<li><a href="https://apps.barc.gov.bd/fertilizer_recommendation/FRG%20English%2030.10.2024.pdf" target="_blank" rel="noopener">BARC Fertilizer Recommendation Guide 2024 (PDF)</a></li>
<li><a href="https://www.bamis.gov.bd/" target="_blank" rel="noopener">DAE BAMIS — ফসল উৎপাদন প্যাকেজ ও কৃষি পরামর্শ</a></li>
</ul>
<p class="fine"><b>ডেটার অবস্থা:</b> ভুট্টা, বোরো ধান, গম ও আলুর প্রাথমিক সরকারি সুপারিশ যুক্ত হয়েছে। এগুলো জাতীয়/মৌসুমভিত্তিক প্যাকেজ বা BAMIS নির্দেশনা; রায়পুরার নির্দিষ্ট জমির মাটি-পরীক্ষাভিত্তিক ডোজ নয়। স্থানীয় কৃষি কর্মকর্তার পরামর্শ এবং মাটি পরীক্ষার ফল প্রাধান্য পাবে। রায়পুরার জমির নির্দিষ্ট ডোজের জন্য খামারি অ্যাপ/স্থানীয় কৃষি কর্মকর্তার মাটি- ও জমিভিত্তিক সুপারিশ প্রাধান্য পাবে।</p>
<a class="btn primary" href="/agri">কৃষি সহায়কে ফিরুন</a>"""
    return shell("সরকারি সার সুপারিশ", body)

@router.get("/agri/weather", response_class=HTMLResponse)
def weather_form():
    opts = "".join(f'<option>{html.escape(c)}</option>' for c in CITIES)
    return shell("আবহাওয়া", f"""<div class="eyebrow">দৈনিক আবহাওয়া বার্তা</div><h1>আপনার এলাকার আবহাওয়া</h1>
<div class="card"><p>পাতা খোলার সঙ্গে সঙ্গে আপনার ফোনের অবস্থান শনাক্ত করার অনুমতি চাওয়া হবে। অনুমতি দিলে আপনার অবস্থানের আবহাওয়া দেখাবে।</p>
<button class="btn primary" type="button" onclick="detectMyLocation()">📍 লোকেশন শনাক্তকরণ</button>
<p id="gps-status" class="fine" role="status" aria-live="polite">আপনার অবস্থানের অনুমতি চাওয়া হচ্ছে…</p>
<div id="gps-weather"></div></div>
<form class="form card" method="post"><label>জেলা/এলাকা<select name="city">{opts}</select></label><button class="btn primary">জেলার আবহাওয়া দেখুন</button></form>
<p class="fine">লোকেশন অনুমতি না দিলে জেলা নির্বাচন করে আবহাওয়া দেখা যাবে। আপনার অবস্থান এই পাতায় আবহাওয়া দেখানোর জন্য ব্যবহার করা হবে।</p>
<script>
async function detectMyLocation() {{
  const status = document.getElementById('gps-status');
  const result = document.getElementById('gps-weather');
  if (!navigator.geolocation) {{ status.textContent = 'আপনার ব্রাউজারে GPS লোকেশন সুবিধা নেই।'; return; }}
  status.textContent = 'আপনার অবস্থানের অনুমতি চাওয়া হচ্ছে…';
  result.innerHTML = '';
  navigator.geolocation.getCurrentPosition(async function(position) {{
    const lat = position.coords.latitude;
    const lon = position.coords.longitude;
    status.textContent = 'অবস্থান শনাক্ত হয়েছে। আবহাওয়ার তথ্য আনা হচ্ছে…';
    try {{
      const url = 'https://api.open-meteo.com/v1/forecast?latitude=' + lat + '&longitude=' + lon + '&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m&daily=precipitation_probability_max,temperature_2m_max,temperature_2m_min&timezone=Asia%2FDhaka&forecast_days=1';
      const response = await fetch(url);
      if (!response.ok) throw new Error('weather unavailable');
      const data = await response.json();
      const cur = data.current;
      const rain = data.daily.precipitation_probability_max[0];
      status.textContent = 'আপনার বর্তমান অবস্থানের আবহাওয়া';
      result.innerHTML = '<div class="card"><h2>এখন ' + cur.temperature_2m + '°C</h2><p>আর্দ্রতা: ' + cur.relative_humidity_2m + '%</p><p>বৃষ্টিপাত: ' + cur.precipitation + ' মিমি</p><p>বাতাস: ' + cur.wind_speed_10m + ' কিমি/ঘণ্টা</p><p>আজ বৃষ্টির সম্ভাবনা: ' + (rain == null ? 'তথ্য নেই' : rain + '%') + '</p><p>সর্বোচ্চ: ' + data.daily.temperature_2m_max[0] + '°C · সর্বনিম্ন: ' + data.daily.temperature_2m_min[0] + '°C</p></div>';
    }} catch (e) {{
      status.textContent = 'লোকেশন পাওয়া গেছে, কিন্তু আবহাওয়ার তথ্য আনা যায়নি। ইন্টারনেট পরীক্ষা করে আবার চেষ্টা করুন।';
    }}
  }}, function(error) {{
    const messages = {{1:'লোকেশন অনুমতি দেওয়া হয়নি। Chrome Site settings থেকে Location → Allow করুন।',2:'ফোনের অবস্থান পাওয়া যাচ্ছে না। ফোনের Location চালু করুন।',3:'লোকেশন পেতে সময় শেষ হয়েছে। আবার চেষ্টা করুন।'}};
    status.textContent = messages[error.code] || 'লোকেশন পাওয়া যায়নি। আবার চেষ্টা করুন.';
  }}, {{enableHighAccuracy:true, timeout:15000, maximumAge:60000}});
}}
window.addEventListener('load', detectMyLocation);
</script>""")

@router.post("/agri/weather", response_class=HTMLResponse)
def weather_result(city: str=Form(...)):
    if city not in CITIES: raise HTTPException(400, "এলাকা নির্বাচন করুন")
    lat, lon = CITIES[city]
    query = urlencode({
        "latitude":lat,"longitude":lon,
        "current":"temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m",
        "daily":"weather_code,precipitation_probability_max,precipitation_sum,temperature_2m_max,temperature_2m_min",
        "timezone":"Asia/Dhaka","forecast_days":7
    })
    try:
        with urlopen("https://api.open-meteo.com/v1/forecast?"+query, timeout=12) as r:
            data=json.loads(r.read().decode())
        cur=data["current"]; day=data["daily"]
        rain=day["precipitation_probability_max"][0] or 0
        advice="বৃষ্টির সম্ভাবনা বেশি—সেচের আগে জমির অবস্থা দেখুন এবং স্প্রে করার সময় বৃষ্টি/বাতাসের নির্দেশনা মানুন।" if rain >= 60 else "বৃষ্টির সম্ভাবনা কম। জমির আর্দ্রতা ও ফসলের অবস্থা দেখে সেচ দিন।"
        weather_labels={0:"পরিষ্কার",1:"মূলত পরিষ্কার",2:"আংশিক মেঘলা",3:"মেঘলা",45:"কুয়াশা",48:"ঘন কুয়াশা",51:"হালকা গুঁড়ি বৃষ্টি",53:"গুঁড়ি বৃষ্টি",55:"ঘন গুঁড়ি বৃষ্টি",61:"হালকা বৃষ্টি",63:"মাঝারি বৃষ্টি",65:"ভারী বৃষ্টি",71:"হালকা তুষার",80:"হালকা বৃষ্টির ঝাপটা",81:"মাঝারি বৃষ্টির ঝাপটা",82:"ভারী বৃষ্টির ঝাপটা",95:"বজ্রসহ বৃষ্টি"}
        forecast_rows=[]
        for i, date in enumerate(day["time"]):
            code=day["weather_code"][i]
            label=weather_labels.get(code,"পরিবর্তনশীল আবহাওয়া")
            p=day["precipitation_probability_max"][i]
            p="তথ্য নেই" if p is None else f"{p}%"
            forecast_rows.append(f"<tr><td>{html.escape(date)}</td><td>{html.escape(label)}</td><td>{day['temperature_2m_min'][i]}°–{day['temperature_2m_max'][i]}°C</td><td>{p}</td><td>{day['precipitation_sum'][i]} মিমি</td></tr>")
        rows="".join(forecast_rows)
        body=f"""<h1>{html.escape(city)}: আবহাওয়া বার্তা</h1>
<div class="card"><h2>এখন {cur['temperature_2m']}°C</h2><p>আর্দ্রতা: {cur['relative_humidity_2m']}%</p><p>বর্তমান বৃষ্টিপাত: {cur['precipitation']} মিমি</p><p>বাতাস: {cur['wind_speed_10m']} কিমি/ঘণ্টা</p><b>{advice}</b></div>
<h2>আগামী ৭ দিনের পূর্বাভাস</h2><div class="card"><table><thead><tr><th>তারিখ</th><th>আবহাওয়া</th><th>তাপমাত্রা</th><th>বৃষ্টির সম্ভাবনা</th><th>বৃষ্টির পরিমাণ</th></tr></thead><tbody>{rows}</tbody></table></div>
<p class="fine">সর্বশেষ তথ্য: {html.escape(cur['time'])} (বাংলাদেশ সময়)। এই বার্তা Open-Meteo পূর্বাভাসের ওপর ভিত্তি করে; স্থানীয় মাঠের অবস্থা ভিন্ন হতে পারে। কৃষিকাজের সিদ্ধান্তের আগে স্থানীয় পূর্বাভাস/কৃষি কর্মকর্তার পরামর্শ যাচাই করুন।</p><a class="btn primary" href="/agri/weather">অন্য জেলা দেখুন</a>"""
    except Exception:
        body="<h1>আবহাওয়ার তথ্য এখন পাওয়া যাচ্ছে না</h1><p>সার্ভার বা আবহাওয়া সেবার সংযোগে সমস্যা হতে পারে। ইন্টারনেট সংযোগ পরীক্ষা করে কিছুক্ষণ পর আবার চেষ্টা করুন।</p><a class='btn primary' href='/agri/weather'>আবার চেষ্টা করুন</a>"
    return shell("আবহাওয়ার ফলাফল", body)

def calc_form(kind):
    cropopts="".join(f"<option>{c}</option>" for c in CROPS)
    return shell(kind, f"""<h1>{kind}</h1><form class="form card" method="post"><label>ফসল<select name="crop">{cropopts}</select></label><label>জমির পরিমাণ<input name="area" type="number" min="0.001" step="any" required></label><label>জমির একক<select name="unit">{''.join(f'<option>{u}</option>' for u in UNITS)}</select></label><label>প্রতি এককে সুপারিশকৃত মাত্রা (কেজি/লিটার/গ্রাম)<input name="rate" type="number" min="0" step="any" required></label><label>মাত্রার একক<input name="measure" maxlength="25" placeholder="যেমন কেজি বা গ্রাম" required></label><button class="btn primary">হিসাব করুন</button></form><p class="fine">সঠিক মাত্রা ফসল, মাটি, জাত, বয়স ও পণ্যের লেবেল/সরকারি সুপারিশের ওপর নির্ভর করে। এখানে কোনো ডিফল্ট ডোজ দেওয়া হয় না; অনুমোদিত সুপারিশ থেকে মাত্রা লিখুন।</p>""")

@router.get("/agri/fertilizer", response_class=HTMLResponse)
def fertilizer_form(): return calc_form("সার হিসাব")
@router.get("/agri/pesticide", response_class=HTMLResponse)
def pesticide_form(): return calc_form("কীটনাশক হিসাব")



# প্রাথমিক রোগ-পোকা তথ্যভান্ডার: লক্ষণ ও সমন্বিত ব্যবস্থাপনা
GUIDE_DATA = {
    "crop": [
        ("ধান","ব্লাস্ট রোগ","পাতায় নৌকার মতো ধূসর কেন্দ্র ও বাদামি কিনারা; শীষের গোড়ায় কালচে দাগ","রোগমুক্ত বীজ ও সহনশীল জাত ব্যবহার; জমিতে সুষম সার, অতিরিক্ত ইউরিয়া এড়ানো; আক্রান্ত জমি নিয়মিত পর্যবেক্ষণ।"),
        ("ধান","মাজরা পোকা","কুশি/মধ্যশীষ শুকিয়ে যায়; কাণ্ডের ভেতরে শূন্যতা ও পোকার লার্ভা","ডিমের গাদা ও আক্রান্ত কুশি নষ্ট; আলোক/ফেরোমন ফাঁদ স্থানীয় পরামর্শে; উপকারী পোকা সংরক্ষণ।"),
        ("ধান","খোলপোড়া","পাতার খোলে ডিম্বাকার ধূসর-সবুজ দাগ, পরে দাগ বড় হয়","ঘন রোপণ ও অতিরিক্ত নাইট্রোজেন এড়ানো; জমির পানি ও আগাছা ব্যবস্থাপনা; আক্রান্ত অংশ নজরে রাখা।"),
        ("টমেটো","আগাম ধসা","পাতায় গোলাকার বাদামি দাগে বলয়ের মতো ছাপ","রোগমুক্ত চারা, ফসল পর্যায়ক্রম, নিচের আক্রান্ত পাতা সরানো এবং পাতায় দীর্ঘক্ষণ পানি জমতে না দেওয়া।"),
        ("আলু","লেট ব্লাইট/মড়ক","পাতায় পানিভেজা কালচে দাগ; আর্দ্র আবহাওয়ায় দ্রুত ছড়ায়","সুস্থ বীজ আলু, সহনশীল জাত, আক্রান্ত গাছ সরানো, জমিতে পানি নিষ্কাশন ও নিয়মিত পর্যবেক্ষণ।"),
        ("বেগুন","ডগা ও ফল ছিদ্রকারী পোকা","ডগা নুয়ে যায়; ফলে ছিদ্র ও ভেতরে পোকার বিষ্ঠা","আক্রান্ত ডগা-ফল সংগ্রহ করে নষ্ট; ফেরোমন ফাঁদ ও নিয়মিত ফল পরীক্ষা; উপকারী পোকা রক্ষা।"),
        ("শসা","ফল মাছি","ফলে ছিদ্র, পচন ও কাঁচা ফল ঝরে পড়া","আক্রান্ত ফল মাটিতে পুঁতে/নষ্ট; ফল ব্যাগিং, জমি পরিষ্কার ও উপযুক্ত প্রলোভন ফাঁদ ব্যবহার।"),
        ("গম","পাতার মরিচা","পাতায় কমলা-বাদামি গুঁড়ার মতো ফুসকুড়ি","রোগমুক্ত বীজ ও সহনশীল জাত; আগাছা/স্বেচ্ছা গমগাছ দমন; রোগ দেখা দিলে কৃষি কর্মকর্তার পরামর্শ।"),
        ("আম","অ্যানথ্রাকনোজ","পাতা, মুকুল ও ফলে কালচে দাগ; আর্দ্রতায় পচন","বাগানে বাতাস চলাচল, আক্রান্ত ডাল-ফল অপসারণ, ঝরা পাতা পরিষ্কার ও সঠিক ছাঁটাই।"),
        ("লিচু","লিচুর মাইট","কচি পাতায় অস্বাভাবিক বাদামি/মখমলি আবরণ ও কুঁকড়ে যাওয়া","আক্রান্ত ডগা ছাঁটাই করে নষ্ট; বাগান পর্যবেক্ষণ এবং বিশেষজ্ঞের পরামর্শে ব্যবস্থা।"),
    ],
    "fish": [
        ("মাছ","এপিজুটিক আলসারেটিভ সিনড্রোম (EUS)","শরীরে লাল ক্ষত, ঘা ও আলসার","পানির গুণাগুণ পরীক্ষা, মৃত/আক্রান্ত মাছ দ্রুত সরানো, পুকুরে দূষণ ও আঘাত কমানো; উপজেলা মৎস্য কর্মকর্তার পরামর্শ নিন।"),
        ("মাছ","অক্সিজেন স্বল্পতা","ভোরে মাছ পানির উপরিভাগে হাঁ করে; খাবার কম খায়","অবিলম্বে পানি প্রবাহ/এয়ারেশন বাড়ান, অতিরিক্ত খাবার বন্ধ রাখুন, পানির গুণাগুণ পরীক্ষা করুন।"),
        ("মাছ","উকুন/পরজীবী","মাছের গায়ে পরজীবী, ঘষাঘষি ও অস্থির সাঁতার","নতুন মাছ কোয়ারেন্টিন, জাল-সরঞ্জাম পরিষ্কার, পানির মান ঠিক রাখা; চিকিৎসা মৎস্য কর্মকর্তার নির্দেশে।"),
    ],
    "livestock": [
        ("গরু","ক্ষুরা রোগ (FMD)","জ্বর, মুখে/জিহ্বায় ঘা, লালা, খোঁড়ানো ও ক্ষুরে ক্ষত","আক্রান্ত পশু আলাদা, চলাচল সীমিত, গোয়ালঘর জীবাণুমুক্ত; দ্রুত প্রাণিসম্পদ কর্মকর্তাকে জানান; টিকা পরিকল্পনা অনুসরণ।"),
        ("গরু","লাম্পি স্কিন ডিজিজ","জ্বর ও শরীরে শক্ত গুটি, লসিকাগ্রন্থি ফুলে যাওয়া","আক্রান্ত পশু আলাদা, মাছি-মশা নিয়ন্ত্রণ, পরিষ্কার-পরিচ্ছন্নতা; দ্রুত ভেটেরিনারি সহায়তা নিন।"),
        ("ছাগল","PPR","জ্বর, নাক-চোখ দিয়ে স্রাব, মুখে ঘা, ডায়রিয়া ও শ্বাসকষ্ট","আক্রান্ত ছাগল আলাদা, পরিষ্কার পানি ও পরিচর্যা, দ্রুত ভেটেরিনারি চিকিৎসা; নিয়মিত টিকাদান।"),
        ("গরু/ছাগল","অভ্যন্তরীণ পরজীবী","দুর্বলতা, রক্তশূন্যতা, ওজন কমা ও পাতলা পায়খানা","মল পরীক্ষা ও পশুচিকিৎসকের পরামর্শে কৃমিনাশক; গোয়ালঘর শুকনো রাখা ও পরিষ্কার খাবার-পানি।"),
    ],
    "poultry": [
        ("মুরগি","নিউক্যাসল/রানীক্ষেত","শ্বাসকষ্ট, সবুজ পাতলা পায়খানা, ঘাড় বেঁকে যাওয়া ও হঠাৎ মৃত্যু","আক্রান্ত পাখি আলাদা, মৃত পাখি নিরাপদে অপসারণ, খামারে জীবাণুনাশ ও বায়োসিকিউরিটি; টিকা সূচি মেনে চলুন।"),
        ("মুরগি","গামবোরো","অবসাদ, পালক ফুলে থাকা, সাদা পানির মতো পায়খানা ও পানিশূন্যতা","বয়সভিত্তিক টিকা, পরিষ্কার পানি, লিটার শুকনো রাখা ও খামারে প্রবেশ নিয়ন্ত্রণ; দ্রুত ভেটেরিনারি পরামর্শ।"),
        ("মুরগি","কক্সিডিওসিস","রক্ত/বাদামি পায়খানা, ঝিমানো, ওজন না বাড়া","লিটার শুকনো রাখা, ভিড় কমানো, পানির পাত্র পরিষ্কার; রোগ নিশ্চিত করে পশুচিকিৎসকের নির্দেশে চিকিৎসা।"),
        ("হাঁস","ডাক প্লেগ","হঠাৎ মৃত্যু, অবসাদ, সবুজাভ পায়খানা ও চোখ-নাক দিয়ে স্রাব","আক্রান্ত হাঁস আলাদা, জলাশয়/খামার পরিষ্কার, নতুন হাঁস কোয়ারেন্টিন এবং টিকা বিষয়ে প্রাণিসম্পদ কর্মকর্তার পরামর্শ।"),
    ],
}
GUIDE_LABELS = {"crop":"ফসল","fish":"মৎস্য","livestock":"প্রাণিজ","poultry":"পোল্ট্রি"}

@router.get("/agri/guide", response_class=HTMLResponse)
def disease_guide(category: str = "crop", q: str = ""):
    if category not in GUIDE_DATA:
        raise HTTPException(404, "বিভাগ পাওয়া যায়নি")
    query = q.strip().lower()
    records = [r for r in GUIDE_DATA[category] if not query or any(query in str(v).lower() for v in r)]
    cards = "".join(
        "<article class='card'><div class='eyebrow'>" + html.escape(r[0]) + "</div><h2>" + html.escape(r[1]) +
        "</h2><p><b>চেনার লক্ষণ:</b> " + html.escape(r[2]) +
        "</p><p><b>প্রাথমিক ব্যবস্থাপনা:</b> " + html.escape(r[3]) + "</p></article>"
        for r in records
    ) or "<article class='card'><p>এই শব্দে কোনো তথ্য পাওয়া যায়নি। অন্য নামে খুঁজুন।</p></article>"
    links = "".join("<a class='btn " + ("primary" if k == category else "light") + "' href='/agri/guide?category=" + k + "'>" + v + "</a> " for k,v in GUIDE_LABELS.items())
    body = "<div class='eyebrow'>iFarmer তথ্যভান্ডার</div><h1>রোগ-পোকা ও স্বাস্থ্য নির্দেশিকা</h1><p>বিভাগ বেছে নিন, রোগ/পোকা বা লক্ষণ লিখে খুঁজুন।</p><p>" + links + "</p><form class='form card' method='get'><input type='hidden' name='category' value='" + category + "'><label>রোগ, পোকা বা লক্ষণ<input name='q' value='" + html.escape(q, quote=True) + "' placeholder='যেমন: ব্লাস্ট, ঘা, শ্বাসকষ্ট'></label><button class='btn primary'>খুঁজুন</button></form><div class='cards'>" + cards + "</div><p class='fine'>এটি প্রাথমিক সচেতনতামূলক তথ্য। লক্ষণ দেখে একা রোগ নিশ্চিত করা যায় না। কীটনাশক/ওষুধের নাম বা মাত্রা অনুমান করে দেওয়া হয়নি। প্রয়োগের আগে উপজেলা কৃষি/মৎস্য/প্রাণিসম্পদ কর্মকর্তার পরামর্শ এবং অনুমোদিত পণ্যের লেবেল অনুসরণ করুন।</p><a href='/agri'>কৃষি সহায়কে ফিরুন</a>"
    return shell("রোগ-পোকা নির্দেশিকা", body)

@router.get("/agri/diagnose", response_class=HTMLResponse)
def diagnose_form():
    crops="".join(f"<option>{html.escape(c)}</option>" for c in CROPS) + "<option>অন্যান্য</option>"
    districts = ["ঢাকা","নরসিংদী","নারায়ণগঞ্জ","গাজীপুর","মুন্সিগঞ্জ","মানিকগঞ্জ","টাঙ্গাইল","কিশোরগঞ্জ","ময়মনসিংহ","জামালপুর","শেরপুর","নেত্রকোনা","ফরিদপুর","রাজবাড়ী","গোপালগঞ্জ","মাদারীপুর","শরীয়তপুর","চট্টগ্রাম","কক্সবাজার","কুমিল্লা","ব্রাহ্মণবাড়িয়া","চাঁদপুর","নোয়াখালী","ফেনী","লক্ষ্মীপুর","সিলেট","মৌলভীবাজার","হবিগঞ্জ","সুনামগঞ্জ","রাজশাহী","নাটোর","নওগাঁ","চাঁপাইনবাবগঞ্জ","পাবনা","সিরাজগঞ্জ","বগুড়া","জয়পুরহাট","রংপুর","দিনাজপুর","গাইবান্ধা","কুড়িগ্রাম","লালমনিরহাট","নীলফামারী","পঞ্চগড়","ঠাকুরগাঁও","খুলনা","যশোর","সাতক্ষীরা","বাগেরহাট","ঝিনাইদহ","মাগুরা","নড়াইল","কুষ্টিয়া","চুয়াডাঙ্গা","মেহেরপুর","বরিশাল","পটুয়াখালী","ভোলা","পিরোজপুর","বরগুনা","ঝালকাঠি","বান্দরবান","রাঙামাটি","খাগড়াছড়ি"]
    districtopts = "".join("<option value=\"" + html.escape(d) + "\">" + html.escape(d) + "</option>" for d in districts)
    return shell("রোগ-পোকা ছবি",f"""<h1>জমা দিন</h1><form class="form card" method="post" enctype="multipart/form-data"><label>চাষ/পালনের ধরন<select name="crop" id="crop-select" required><optgroup label="ফসল">{crops}</optgroup><optgroup label="মৎস্য"><option>মৎস্য চাষ</option></optgroup><optgroup label="প্রাণিজ"><option>প্রাণিজ - গরু</option><option>প্রাণিজ - ছাগল</option><option>প্রাণিজ - ভেড়া</option></optgroup><optgroup label="পোল্ট্রি"><option>পোল্ট্রি - মুরগি</option><option>পোল্ট্রি - হাঁস</option><option>পোল্ট্রি - টার্কি</option><option>পোল্ট্রি - কোয়েল</option></optgroup></select></label><label>জেলা<select name="area" required><option value="">জেলা নির্বাচন করুন</option>{districtopts}</select></label><label>লক্ষণ/সমস্যা<input name="symptoms" maxlength="500" placeholder="পাতায় দাগ, পোকা, পচন ইত্যাদি"></label><label id="other-crop-wrap" style="display:none">অন্যান্য ফসল/ফলের নাম<input name="other_crop" id="other-crop" maxlength="80" placeholder="ফসল বা ফলের নাম লিখুন"></label><script>document.getElementById("crop-select").addEventListener("change",function(){{const w=document.getElementById("other-crop-wrap");const i=document.getElementById("other-crop");w.style.display=this.value==="অন্যান্য"?"block":"none";i.required=this.value==="অন্যান্য";}});</script><label>ছবি (JPG/PNG/WebP)<input type="file" name="photo" accept="image/*" required></label><button class="btn primary">ছবি জমা দিন</button></form><p class="fine">ছবি জমা দিলে AI সম্ভাব্য রোগ, পোকা, পুষ্টিঘাটতি, কারণ, করণীয় ও প্রতিরোধ বিশ্লেষণ করবে। এটি সম্ভাব্য মূল্যায়ন—নিশ্চিত রোগনির্ণয় নয়। ফ্রি ব্যবহারের সীমা শেষ হলে কোনো পেইড চার্জ ছাড়াই সেবা সাময়িক বন্ধ থাকবে।</p>""")


@router.post("/agri/diagnose", response_class=HTMLResponse)
async def diagnose_submit(crop: str=Form(...), area: str=Form(...), symptoms: str=Form(""), other_crop: str=Form(""), photo: UploadFile=File(...)):
    if crop == "অন্যান্য":
        crop = other_crop.strip()[:80]
        if not crop:
            raise HTTPException(400, "অন্যান্য ফসল বা ফলের নাম লিখুন")
    if (crop not in DIAGNOSIS_TYPES and not other_crop.strip()) or photo.content_type not in ("image/jpeg","image/png","image/webp"):
        raise HTTPException(400,"ফসল ও JPG/PNG/WebP ছবি দিন")
    data=await photo.read(5*1024*1024+1)
    if len(data)>5*1024*1024: raise HTTPException(400,"ছবি ৫ MB-এর কম হতে হবে")
    if not data: raise HTTPException(400,"ছবি খালি")
    answer, error = diagnose_crop_image(crop, area[:80], symptoms[:500], data, photo.content_type)
    if error:
        message = html.escape(error)
        body=f"<h1>AI বিশ্লেষণ আপাতত পাওয়া যাচ্ছে না</h1><div class='card'><p>{message}</p><p>কোনো পেইড সেবা বা চার্জ চালু করা হয়নি।</p></div><a href='/agri/diagnose'>আবার চেষ্টা করুন</a>"
    else:
        import re
        # Normalize heading labels, then split even if Gemini returns a single paragraph.
        text_answer = answer.replace("\\r", "\\n")
        text_answer = re.sub(r"(?m)^\\s*#{1,3}\\s*", "", text_answer)
        labels = [
            ("সনাক্তকরণ", "১. সনাক্তকরণ"),
            ("রোগ নির্ণয়", "২. রোগ নির্ণয়"),
            ("সমাধান", "৩. সমাধান"),
            ("প্রতিকার ও প্রতিরোধ", "৪. প্রতিকার ও প্রতিরোধ"),
        ]
        # Split on section labels whether they occur on separate lines or inline.
        for label, numbered in labels:
            text_answer = re.sub(r"(?i)\\s*(?:#{1,3}\\s*)?(?:\\d+[.)]\\s*)?" + re.escape(label) + r"\\s*[:：—-]?\\s*", "\\n§§" + numbered + "§§\\n", text_answer)
        parts = re.split(r"§§(.*?)§§", text_answer)
        sections = []
        if len(parts) > 1:
            for i in range(1, len(parts), 2):
                heading = parts[i].strip()
                content = parts[i+1].strip() if i+1 < len(parts) else ""
                sections.append((heading, content))
        else:
            # Fallback: keep the AI response under clear, explicit section headings.
            sections = [(heading, "এই অংশের বিস্তারিত তথ্য AI-এর উত্তরে আলাদা করে পাওয়া যায়নি।\n\n" + text_answer.strip()) for _, heading in labels]
        heading_colors = {"১. সনাক্তকরণ":"#16803c", "২. রোগ নির্ণয়":"#b76a00", "৩. সমাধান":"#2563eb", "৪. প্রতিকার ও প্রতিরোধ":"#7c3aed"}
        rendered = []
        for heading, content in sections:
            color = heading_colors.get(heading, "#176b45")
            rendered.append("<section class='diagnosis-section' style='margin:16px 0;padding:16px;border:1px solid #e5e7eb;border-radius:12px;background:#fff'>")
            rendered.append("<h2 style='margin:0 0 12px;color:" + color + ";font-size:1.15rem'>" + html.escape(heading) + "</h2>")
            rendered.append("<div style='line-height:1.8;white-space:normal'>" + "<br>".join(html.escape(line.strip()) for line in content.splitlines() if line.strip()) + "</div></section>")
        safe_answer = "".join(rendered)
        body=f"<h1>সম্ভাব্য রোগ/পোকা বিশ্লেষণ</h1><div class='diagnosis-report'>{safe_answer}</div><p class='fine'>এটি ছবিভিত্তিক AI-এর সম্ভাব্য মূল্যায়ন, নিশ্চিত রোগনির্ণয় নয়। স্প্রে বা চিকিৎসার আগে স্থানীয় কৃষি কর্মকর্তা এবং নিবন্ধিত পণ্যের লেবেল অনুসরণ করুন।</p><a href='/agri/diagnose'>আরেকটি ছবি বিশ্লেষণ করুন</a>"
    return shell("AI বিশ্লেষণ", body)

@router.post("/agri/{kind}", response_class=HTMLResponse)
def calculate(kind: str, crop: str=Form(...), area: float=Form(...), unit: str=Form(...), rate: float=Form(...), measure: str=Form(...)):
    if kind not in ("fertilizer","pesticide") or crop not in CROPS or unit not in UNITS or area<=0 or rate<0:
        raise HTTPException(400,"সঠিক তথ্য দিন")
    total=area*UNITS[unit]*rate
    label="সার" if kind=="fertilizer" else "কীটনাশক"
    warning = "কীটনাশকের ক্ষেত্রে শুধু সংশ্লিষ্ট ফসল ও পোকার জন্য নিবন্ধিত পণ্যের লেবেল অনুসরণ করুন। PPE, অপেক্ষাকাল (PHI), পুনঃপ্রবেশ সময় ও বাতাসের নির্দেশনা মানুন।" if kind=="pesticide" else "মাটি পরীক্ষা ও কৃষি সম্প্রসারণ অধিদপ্তরের ফসলভিত্তিক সুপারিশ মিলিয়ে নিন।"
    return shell("হিসাবের ফল",f"<h1>{label}র হিসাব</h1><div class='card'><p>ফসল: {html.escape(crop)}</p><p>জমি: {area:g} {html.escape(unit)}</p><h2>মোট প্রয়োজন: {total:.3f} {html.escape(measure)}</h2></div><p class='fine'>{warning}</p><a href='/agri'>কৃষি সহায়কে ফিরুন</a>")



